```python
import numpy as np
import pandas as pd
```


```python
import matplotlib.pyplot as plt
import seaborn as sns

```


```python
%matplotlib inline
```


```python
data=pd.read_csv("Kyphosis.csv")
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Kyphosis</th>
      <th>Age</th>
      <th>Number</th>
      <th>Start</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>absent</td>
      <td>71</td>
      <td>3</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>absent</td>
      <td>158</td>
      <td>3</td>
      <td>14</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>present</td>
      <td>128</td>
      <td>4</td>
      <td>5</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>absent</td>
      <td>2</td>
      <td>5</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>absent</td>
      <td>1</td>
      <td>4</td>
      <td>15</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 81 entries, 0 to 80
    Data columns (total 5 columns):
     #   Column      Non-Null Count  Dtype 
    ---  ------      --------------  ----- 
     0   Unnamed: 0  81 non-null     int64 
     1   Kyphosis    81 non-null     object
     2   Age         81 non-null     int64 
     3   Number      81 non-null     int64 
     4   Start       81 non-null     int64 
    dtypes: int64(4), object(1)
    memory usage: 3.3+ KB
    


```python
data.shape
```




    (81, 5)




```python
data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Age</th>
      <th>Number</th>
      <th>Start</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>81.000000</td>
      <td>81.000000</td>
      <td>81.000000</td>
      <td>81.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>41.000000</td>
      <td>83.654321</td>
      <td>4.049383</td>
      <td>11.493827</td>
    </tr>
    <tr>
      <th>std</th>
      <td>23.526581</td>
      <td>58.104251</td>
      <td>1.619423</td>
      <td>4.883962</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>2.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>21.000000</td>
      <td>26.000000</td>
      <td>3.000000</td>
      <td>9.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>41.000000</td>
      <td>87.000000</td>
      <td>4.000000</td>
      <td>13.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>61.000000</td>
      <td>130.000000</td>
      <td>5.000000</td>
      <td>16.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>81.000000</td>
      <td>206.000000</td>
      <td>10.000000</td>
      <td>18.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.pairplot(data,hue='Kyphosis',palette='Set1')
```




    <seaborn.axisgrid.PairGrid at 0x6b0490d5e0>




    
![png](output_7_1.png)
    



```python
X = data.drop('Kyphosis',axis=1)
y = data['Kyphosis']
```


```python
from sklearn.model_selection import train_test_split
```


```python
 X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3)
```


```python
 from sklearn.tree import DecisionTreeClassifier
```


```python
 dtree = DecisionTreeClassifier()
```


```python
dtree.fit(X_train, y_train)
```




    DecisionTreeClassifier()




```python
predictions = dtree.predict(X_test)
```


```python
from sklearn.metrics import classification_report, confusion_matrix
```


```python
print(classification_report(y_test,predictions))
```

                  precision    recall  f1-score   support
    
          absent       0.81      0.94      0.87        18
         present       0.75      0.43      0.55         7
    
        accuracy                           0.80        25
       macro avg       0.78      0.69      0.71        25
    weighted avg       0.79      0.80      0.78        25
    
    


```python
print(confusion_matrix(y_test,predictions))
```

    [[17  1]
     [ 4  3]]
    


```python
features = list(data.columns[1:])
features
```




    ['Kyphosis', 'Age', 'Number', 'Start']




```python
X = df.drop('Kyphosis',axis=1)
y = df['Kyphosis']
 
```


```python
X_train, X_test, y_train, y_test = train_test_split (X, y, test_size=0.30)

```


```python
dtree = DecisionTreeClassifier()
dtree.fit(X_train,y_train)

```




    DecisionTreeClassifier()




```python
from sklearn.metrics import accuracy_score
```


```python
y_pred = dtree.predict(X_test)
accuracy = accuracy_score(y_test,y_pred)
```


```python
accuracy
```




    0.76




```python
from sklearn.ensemble import RandomForestClassifier
```


```python
rfc = RandomForestClassifier(n_estimators=200)
```


```python
rfc.fit(X_train,y_train)
```




    RandomForestClassifier(n_estimators=200)




```python
rfc_predictions = rfc.predict(X_test)
```


```python
print(classification_report(y_test,rfc_predictions))
```

                  precision    recall  f1-score   support
    
          absent       0.86      0.90      0.88        21
         present       0.33      0.25      0.29         4
    
        accuracy                           0.80        25
       macro avg       0.60      0.58      0.58        25
    weighted avg       0.78      0.80      0.79        25
    
    


```python
print(confusion_matrix(y_test,rfc_predictions))
```

    [[19  2]
     [ 3  1]]
    


```python
accuracy = accuracy_score(y_test,rfc_predictions)
```


```python
accuracy
```




    0.8




```python
 import numpy as np
import matplotlib.pyplot as plt
from sklearn import svm, datasets
# import some data to play with
iris = datasets.load_iris()
X = iris.data[:, :2] # we only take the first two features. We could
 # avoid this ugly slicing by using a two-dim dataset
y = iris.target
```


```python
 
```


```python

```
